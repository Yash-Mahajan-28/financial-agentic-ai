"""Dataset loading, Impact Matrix, gap analysis, checklist, CSV export and trade questions."""

from __future__ import annotations

import csv
import io
from pathlib import Path

import pytest

from app.analysis.core import checklist, evaluate_matrix, gap_analysis, select_rules, summarize
from app.analysis.export import MATRIX_COLUMNS, iter_matrix_csv, safe_cell
from app.analysis.trade_query import parse_trade_query, run_trade_query
from app.engine.dataset import DatasetError, load_trades, validate_against_schema


def test_csv_ingestion_coerces_types_from_schema(dataset) -> None:  # type: ignore[no-untyped-def]
    assert dataset.count == 200
    assert dataset.columns == [
        "Trade_ID",
        "Asset_Class",
        "Timestamp",
        "Counterparty_LEI",
        "Price",
        "Quantity",
        "Currency",
        "Maturity_Date",
        "Underlying_ISIN",
    ]
    t4 = dataset.by_id()["T000004"]
    assert t4["Price"] == -99.9 and isinstance(t4["Quantity"], int)
    t1 = dataset.by_id()["T000001"]
    assert t1["Maturity_Date"] is None and t1["Underlying_ISIN"] is None  # empty -> missing
    assert dataset.warnings == []


def test_bad_csv_values_are_reported(tmp_path: Path, schema) -> None:  # type: ignore[no-untyped-def]
    f = tmp_path / "t.csv"
    f.write_text("Trade_ID,Asset_Class,Timestamp,Counterparty_LEI,Price,Quantity,Currency\nT1,FX,2024-01-01T00:00:00Z,X,abc,1.5,USD\n")
    ds = load_trades(f, schema)
    assert any("Price expected a number" in w for w in ds.warnings)
    assert any("Quantity expected an integer" in w for w in ds.warnings)
    with pytest.raises(DatasetError):
        load_trades(tmp_path / "missing.csv", schema)


def test_impact_matrix_on_supplied_data_is_deterministic(dataset, rules) -> None:  # type: ignore[no-untyped-def]
    rule_list = list(rules.values())
    rows = evaluate_matrix(dataset, rule_list)
    assert len(rows) == 200 * 8
    s = summarize(rows, dataset, rule_list)
    assert s["status_counts"] == {"PASS": 1021, "FAIL": 209, "NOT_APPLICABLE": 370, "ERROR": 0}
    assert s["unique_impacted_trades"] == 156
    by_rule = {r["rule_id"]: r for r in s["by_rule"]}
    assert by_rule["MIFID-2"]["fail"] == 8  # negative prices
    assert by_rule["EMIR-2"]["fail"] == 8  # zero quantities
    assert by_rule["FCA-1"]["fail"] == 9  # XYZ currency
    assert by_rule["MIFID-1"]["fail"] == 37  # missing / malformed LEIs
    assert by_rule["MIFID-4"]["fail"] == 1  # 2017 trade
    assert by_rule["EMIR-1"]["not_applicable"] == 165  # only derivatives are in scope
    assert rows == evaluate_matrix(dataset, rule_list)  # same input, same output
    t4 = next(r for r in rows if r["trade_id"] == "T000004" and r["rule_id"] == "MIFID-2")
    assert t4["status"] == "FAIL" and t4["actual_values"] == {"Price": -99.9}
    assert t4["rule_source"] == "rules_mifid.json#MIFID-2"


def test_rule_selection_by_regulator(rules) -> None:  # type: ignore[no-untyped-def]
    assert [r.id for r in select_rules(list(rules.values()), ["fca"])] == ["FCA-1", "FCA-2"]
    assert [r.id for r in select_rules(list(rules.values()), rule_ids=["mifid-2"])] == ["MIFID-2"]


def test_gap_analysis_separates_rule_and_schema_findings(dataset, rules, schema) -> None:  # type: ignore[no-untyped-def]
    rows = evaluate_matrix(dataset, list(rules.values()))
    g = gap_analysis(rows, validate_against_schema(dataset, schema))
    cats = {c["category"]: c for c in g["rule_findings"]["by_category"]}
    assert cats["negative_value"]["failed_evaluations"] == 8
    assert cats["value_not_allowed"]["fields"] == ["Currency"]
    assert g["rule_findings"]["conditional_requirements"]["rule_ids"] == ["FCA-2", "MIFID-3"]
    schema_checks = {(b["field"], b["check"]): b["count"] for b in g["schema_findings"]["by_check"]}
    assert schema_checks[("Counterparty_LEI", "required")] == 18
    assert schema_checks[("Currency", "enum")] == 9


def test_checklist_dataset_and_single_trade(dataset, rules) -> None:  # type: ignore[no-untyped-def]
    rule_list = list(rules.values())
    rows = evaluate_matrix(dataset, rule_list)
    agg = checklist(rows, rule_list)
    mifid3 = next(i for i in agg["items"] if i["rule_id"] == "MIFID-3")
    assert mifid3["applicability"].startswith("Conditional")
    assert mifid3["applicable"] == 35 and mifid3["fail"] == 9
    one = checklist(rows, rule_list, "T000004")
    statuses = {i["rule_id"]: i["status"] for i in one["items"]}
    assert statuses["MIFID-2"] == "FAIL" and statuses["MIFID-3"] == "NOT_APPLICABLE"


def test_csv_export_columns_and_formula_injection_guard(dataset, rules) -> None:  # type: ignore[no-untyped-def]
    rows = [r for r in evaluate_matrix(dataset, list(rules.values())) if r["status"] == "FAIL"][:5]
    rows[0] = {**rows[0], "explanation": '=HYPERLINK("http://evil")'}
    text = "".join(iter_matrix_csv(rows))
    parsed = list(csv.reader(io.StringIO(text)))
    assert parsed[0] == MATRIX_COLUMNS
    assert len(parsed) == 6
    assert parsed[1][9].startswith("'=HYPERLINK")
    assert safe_cell("-99.9") == "-99.9"  # numbers are data, not formulas
    assert safe_cell("@SUM(A1)") == "'@SUM(A1)"
    assert safe_cell("+cmd") == "'+cmd"


@pytest.mark.parametrize(
    ("question", "count"),
    [
        ("Which trades are missing a Counterparty LEI?", 18),
        ("Show me all Derivative trades that do not have a Maturity Date.", 9),
        ("List any trade where the price is negative.", 8),
        ("How many trades use a currency that is not in the approved list (USD, EUR, GBP, JPY, CHF)?", 9),
        ("Which trades were executed before 2018‑01‑01?", 1),
    ],
)
def test_supported_trade_questions(question: str, count: int, dataset, schema) -> None:  # type: ignore[no-untyped-def]
    parsed = parse_trade_query(question, schema)
    assert parsed.matched
    assert len(run_trade_query(parsed, dataset)) == count


def test_document_questions_are_not_treated_as_trade_queries(schema) -> None:  # type: ignore[no-untyped-def]
    assert not parse_trade_query("Give me the paragraph that defines the LEI requirement under MiFID II", schema).matched
    assert not parse_trade_query("Show the latest FCA guidance that mentions FX trades", schema).matched
